import json,subprocess,selectors,time,re
from pathlib import Path
b=Path(__file__).resolve().parent
p=subprocess.Popen(['/Users/bytedance/workspace/doubao_wrapper/litep'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(b/'capture-mcp.stderr').open('w'),text=True)
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);seq=0
args={'serial':'9c2841a4','package':'com.shadps4.android','service':'com.shadps4.android.service.FexSessionService'}
a=['adb','-s','9c2841a4']
def adb(*cmd):return subprocess.check_output(a+list(cmd),text=True)
def call(name,args):
 global seq
 seq+=1;p.stdin.write(json.dumps(dict(jsonrpc='2.0',id=seq,method='tools/call',params=dict(name=name,arguments=args)))+'\n');p.stdin.flush()
 assert sel.select(60),'MCP timeout '+name
 r=json.loads(p.stdout.readline());assert r.get('id')==seq,r;r=r['result'];assert not r.get('isError'),r
 return json.loads(r['content'][0]['text'])
def save(n,d):(b/n).write_text(json.dumps(d,indent=2)+'\n')
try:
 call('server.get_version',{})
 before=adb('shell','dumpsys','activity','service','com.shadps4.android/.service.FexSessionService','debug_status');(b/'aligned-before.txt').write_text(before)
 assert 'generation: 2' in before and 'stage: Running' in before
 adb('shell','dumpsys','activity','service','com.shadps4.android/.service.FexSessionService','gpu_timing','start')
 k=subprocess.Popen(['python3','/Users/bytedance/workspace/spatial_mcp_publish/dev_tools/mcp/litep/tools/capture_kgsl.py','--serial','9c2841a4','--package','com.shadps4.android','--rootctl','/Users/bytedance/workspace/devices/tools/android-root/rootctl','--clock-helper',str(b.parent/'bloodborne-perf-20260919/kgsl-clock'),'--seconds','24','--total-mib','384','--output',str(b/'kgsl-aligned')],stdout=subprocess.PIPE,stderr=(b/'kgsl-aligned.stderr').open('w'),text=True)
 started=json.loads(k.stdout.readline());save('kgsl-aligned-start.json',started)
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  r=subprocess.run(a+['shell','cat',started['remote']+'/status'],capture_output=True,text=True)
  if r.stdout.strip()=='armed':break
  time.sleep(.2)
 else:raise RuntimeError('KGSL never armed')
 result=call('android_capture',args|{'action':'file','seconds':10,'max_mib':128});save('aligned-capture-start.json',result);print('prof started',result,flush=True)
 rest=k.communicate(timeout=65)[0];(b/'kgsl-aligned-complete.txt').write_text(rest);assert k.returncode==0
 final=call('android_capture',args|{'action':'status'});save('aligned-capture-ready.json',final);assert final['capture_state']=='ready',final
 pull=call('start_capture_pull',args|{'expected_pid':'6163','capture_id':final['capture_id'],'output_directory':str(b)})
 while pull['active']:
  time.sleep(.5);pull=call('capture_pull_status',{'transfer_id':pull['transfer_id']})
 save('aligned-pull.json',pull);assert pull['state']=='ready',pull
 after=adb('shell','dumpsys','activity','service','com.shadps4.android/.service.FexSessionService','debug_status');(b/'aligned-after.txt').write_text(after)
 for f in ['pid','generation','run_uuid']:
  assert re.search(r'\n\s+'+f+r': (\S+)',before)[1]==re.search(r'\n\s+'+f+r': (\S+)',after)[1]
 print('capture ready',pull['result'],flush=True)
finally:
 adb('shell','dumpsys','activity','service','com.shadps4.android/.service.FexSessionService','gpu_timing','stop')
 p.stdin.close();p.wait(timeout=15)
