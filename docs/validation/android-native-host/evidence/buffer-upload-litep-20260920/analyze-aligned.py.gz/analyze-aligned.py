import json,subprocess,selectors,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
b=root/'aligned-analysis';b.mkdir(exist_ok=True)
p=subprocess.Popen(['/Users/bytedance/workspace/doubao_wrapper/litep'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(b/'installed-mcp.stderr').open('w'),text=True)
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);seq=0

def call(name,args):
 global seq
 seq+=1;p.stdin.write(json.dumps(dict(jsonrpc='2.0',id=seq,method='tools/call',params=dict(name=name,arguments=args)))+'\n');p.stdin.flush()
 assert sel.select(120),'MCP timeout: '+name
 r=json.loads(p.stdout.readline());assert r.get('id')==seq,r
 r=r['result'];assert not r.get('isError'),r
 return json.loads(r['content'][0]['text'])
def save(n,r):(b/n).write_text(json.dumps(r,indent=2)+'\n')
try:
 version=call('server.get_version',{});save('installed-version.json',version);print('version',version,flush=True)
 prof=Path(json.loads((root/'aligned-pull.json').read_text())['result']['path']);cap=root/'kgsl-aligned/capture.json';m=json.loads(cap.read_text())
 sidecar={'schema':'litep.kgsl.sidecar.v1','prof':{'sha256':hashlib.sha256(prof.read_bytes()).hexdigest(),'pid':m['pid'],'boot_id':m['boot_id'],'process_start_ticks':m['process_start_ticks']},'capture':str(cap),'capture_sha256':hashlib.sha256(cap.read_bytes()).hexdigest()};save('scene.kgsl.json',sidecar)
 idx=call('index_trace',{'path':str(prof),'index_directory':str(b/'index'),'sdk_revision':'e00321ea40c4c608aff74a787200bc59493eea19','scene_id':'Bloodborne clinic character stationary facing shelves; PID6163 generation2 c14cf608'})
 while idx['active']:
  time.sleep(2);idx=call('trace_index_status',{'index_id':idx['index_id']});print('index',idx.get('state'),idx.get('events'),flush=True)
 save('index-status.json',idx);assert idx['state']=='ready',idx
 ident=idx['index_id']
 a=call('query_async_flows',dict(index_id=ident,order='queue_latency',limit=20));save('async.json',a);print('flows',a['status_counts'],flush=True)
 side=call('load_kgsl_sidecar',dict(index_id=ident,path=str(b/'scene.kgsl.json')));save('sidecar-status.json',side);print('sidecar',side,flush=True)
 try:
  r=call('analyze_cpu_gpu_bottlenecks',dict(index_id=ident,sidecar_id=side['sidecar_id'],top=30));save('cpu-gpu.json',r);print('cpu-gpu',r['elapsed_ms'],r['cpu_threads'][:2],flush=True)
  frames=call('query_indexed_frames',dict(index_id=ident,order='slowest',limit=100));save('frames.json',frames)
  valid=[f for f in frames['rows'] if f['valid'] and side['safe_start_ns']<=f['start_ns']<f['end_ns']<=side['safe_end_ns']]
  assert valid,'no fully covered scene frame'
  chosen=valid[:3]+[valid[len(valid)//2]]
  for f in chosen:
   r=call('analyze_frame_contributions',dict(index_id=ident,sdk_frame=f['sdk_frame'],sidecar_id=side['sidecar_id'],top=15));save('frame-'+str(f['sdk_frame'])+'.json',r);print('frame',r['frame'],'deps',r['owner_wait_dependencies'][:1],flush=True)
 finally:call('close_kgsl_sidecar',dict(sidecar_id=side['sidecar_id']))
finally:
 p.stdin.close();p.wait(timeout=15)
