from pathlib import Path
import json,sys,sqlite3,re,collections,bisect
sys.path.insert(0,'/Users/bytedance/workspace/spatial_mcp_publish/dev_tools/mcp/litep')
sys.path.append('/Users/bytedance/workspace/spatial_mcp_publish/dev_tools/mcp/litep/sdk/skills/spatial-trace-analyzer/scripts')
from wait_chains import read_index
from kgsl_sidecar import load_sidecar
from frame_contributions import states
from analysis import distribution
b=Path(__file__).resolve().parent;j=json.loads((b/'aligned-analysis/index-status.json').read_text());db=sqlite3.connect('file:'+j['index_path']+'?mode=ro',uri=True)
m=json.loads((b/'capture/capture.json').read_text());p=json.loads((b/'probes-v3/auto-tag.json').read_text());byid={v['id']:v for v in p['probes']}
d=load_sidecar(b/'aligned-analysis/scene.kgsl.json',j['sha256'],j['integrity']);print('sidecar ready',flush=True)
a,z=j['start_ns'],j['end_ns'];pending={};spans=[];diag=collections.Counter()
pattern=re.compile(r'^GuestAuto\.([0-9a-f]{16})\.c(\d+)\.t(\d+)\.g(\d+)\.i(\d+)\.p(\d+)_(begin|elapsed)_ns$')
for ts,tid,name,value in db.execute("SELECT ts,tid,json_extract(data,'$.name'),value FROM events WHERE kind='Counter' AND json_extract(data,'$.name') LIKE 'GuestAuto.%' ORDER BY id"):
 match=pattern.match(name);assert match,name
 dg,c,t,g,i,pid,part=match.groups();assert dg==m['profile_sha256'][:16] and int(c)==m['process']['context'];key=tid,name.rsplit('_',2)[0];value=int(value);pid=int(pid)
 if part=='begin':pending[key]=(value,ts,pid);continue
 if key not in pending:diag['missing_begin']+=1;continue
 start,stamp,probe=pending.pop(key);assert pid==probe and value>=0 and start<=stamp+1000000
 end=start+value
 if start<a or end>z:diag['boundary']+=1;continue
 assert end<=ts+1000000
 spans.append(dict(tid=int(tid),guest_thread=int(t),start=start,end=end,id=pid,offset=byid[pid]['begin']['offset'],name=byid[pid]['name']))
(b/'job-spans.json').write_text(json.dumps(spans))
waits=read_index(db).report(a,z,100,True);(b/'wait-rows.json').write_text(json.dumps(waits,indent=2))
# SQL only complete HLE intervals. Per-lane children are intersected, never added to their outer call.
hles=collections.defaultdict(list)
for tid,name,x,y in db.execute("SELECT e.tid,json_extract(e.data,'$.name'),i.start,i.end FROM intervals i JOIN events e ON e.id=i.begin_id WHERE e.kind='SpanBegin' AND json_extract(e.data,'$.name') LIKE 'HLE.%' ORDER BY i.start"):
 hles[int(tid)].append((x,y,name))
ends={tid:[r[0] for r in rows] for tid,rows in hles.items()}
def summarize(selected):
 groups=collections.defaultdict(list)
 for r in selected:groups[r['offset'],r['name']].append(r)
 result=[]
 for (off,name),rs in groups.items():
  st=collections.Counter();hle=collections.Counter();hlecpu=collections.Counter()
  for r in rs:
   st.update(states(d,r['tid'],r['start'],r['end']))
   rows=hles.get(r['tid'],[]); k=max(0,bisect.bisect_left(ends.get(r['tid'],[]),r['start'])-1)
   while k<len(rows) and rows[k][0]<r['end']:
    x,y,n=rows[k];k+=1;lo=max(x,r['start']);hi=min(y,r['end'])
    if hi>lo:
     hle[n]+=(hi-lo)/1e6;hlecpu[n]+=states(d,r['tid'],lo,hi)['on_cpu_ms']
  result.append(dict(offset=hex(off),name=name,count=len(rs),sum_ms=sum(r['end']-r['start'] for r in rs)/1e6,distribution=distribution([r['end']-r['start'] for r in rs]),states=dict(st),hle_elapsed_ms=hle.most_common(6),hle_on_cpu_ms=hlecpu.most_common(6)))
 result.sort(key=lambda r:-r['sum_ms']);return result
whole=summarize(spans);(b/'job-summary.json').write_text(json.dumps(dict(diagnostics=dict(diag),groups=whole),indent=2));print('global',json.dumps(whole[:9]),flush=True)
# Last notifier lane only, bounded by the explicit enqueue and selected notify.
long=[]
for w in waits['rows']:
 e=w['enqueued'];n=w.get('notified')
 if e['tid']!=24841 or not n or e['caller'].get('Parent1')!=0x1d186c5:continue
 long.append(w)
long.sort(key=lambda w:-(w['notified']['ts_ns']-w['enqueued']['ts_ns']))
answers=[]
for w in long[:4]:
 e,n=w['enqueued'],w['notified'];x,y=e['ts_ns'],n['ts_ns'];tid=n['tid']
 selected=[dict(r,start=max(x,r['start']),end=min(y,r['end'])) for r in spans if r['tid']==tid and r['start']<y and r['end']>x]
 item=dict(wait=w,producer_states=states(d,tid,x,y),producer_probes=summarize(selected));answers.append(item)
(b/'long-task-waits.json').write_text(json.dumps(answers,indent=2));print('waits',[(w['notified']['ts_ns']-w['enqueued']['ts_ns'])/1e6 for w in long[:4]],flush=True)
