from pathlib import Path
import json,sqlite3,bisect,re
b=Path(__file__).resolve().parent;s=json.load(open(b/'job-spans.json'));j=json.load(open(b/'aligned-analysis/index-status.json'));c=sqlite3.connect('file:'+j['index_path']+'?mode=ro',uri=True)
h={}
for tid,x,y in c.execute("SELECT e.tid,i.start,i.end FROM intervals i JOIN events e ON e.id=i.begin_id WHERE json_extract(e.data,'$.name')='HLE.sceKernelWaitSema' ORDER BY i.start"):
 h.setdefault(int(tid),[]).append((x,y))
starts={k:[a for a,z in v] for k,v in h.items()};gaps=[]
for r in s:
 if r['offset']!=0x20336f3:continue
 rows=h.get(r['tid'],[]);k=bisect.bisect_left(starts.get(r['tid'],[]),r['start'])
 if k<len(rows) and rows[k][1]<=r['end']:gaps.append((rows[k][0]-r['start'])/1e6)
gaps.sort();assert gaps
anchors=[]
for name in ['start','end']:
 t=(b/('kgsl-jobs/anchor-'+name+'.txt')).read_text();anchors.append({k:int(v) for k,v in re.findall(r'(mono_before|raw_tick|mono_after)=(\d+)',t)})
f=(anchors[1]['raw_tick']-anchors[0]['raw_tick'])*1e9/((anchors[1]['mono_before']+anchors[1]['mono_after']-anchors[0]['mono_before']-anchors[0]['mono_after'])/2)
r=dict(count=len(gaps),min_ms=gaps[0],p50_ms=gaps[len(gaps)//2],p90_ms=gaps[len(gaps)*9//10],max_ms=gaps[-1],mean_ms=sum(gaps)/len(gaps),measured_counter_hz=f,budget_ticks=200000,budget_ms=200000/f*1000,under_10_ms=sum(x<10 for x in gaps),between_10_and_11_ms=sum(10<=x<11 for x in gaps),notes='Queue-acquire call begin to first HLE semaphore entry; includes PthreadSelf/probe/scheduling. Not pure spin CPU. Budget from exact static queue initializer; runtime field not directly read.')
(b/'spin-budget-evidence.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
